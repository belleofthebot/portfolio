# Drive the 505

A learning app for nervous adult drivers in Albuquerque, New Mexico.

**[Open the app →](https://belleofthebot.github.io/drive-the-505/)**

Learning to drive as an adult is a different problem from learning at sixteen.
The information is scattered across a state handbook, a car manual, and whatever
a well-meaning person tells you in a parking lot — and none of it is organised
around the thing that actually makes it hard, which is nerve rather than
knowledge.

![The app on a phone: the Drive the 505 home screen with module cards for Car Knowledge, Driving Theory, NM Road Rules and ABQ Geography](docs/screenshot-home.png)

## What's in it

| | |
|---|---|
| Study modules | 4 — car knowledge (9 topics), driving theory (8), New Mexico road rules (20), Albuquerque geography (13) |
| Flashcards | 80, across 4 decks |
| Quiz questions | 49, with explanations on wrong answers |
| Interactive map | 21 named roads on a hand-authored SVG of the city grid, with a find-the-road quiz mode |
| Car matcher | 6 questions over 12 vehicles |
| Also | a staged first-month plan, and buying/choosing guides |

Progress is stored in `localStorage` under a single key and persists between
sessions. Nothing is sent anywhere — there is no server, no analytics, and no
network request except the Google Fonts stylesheet.

## How it's built

**One self-contained HTML file. No build step, no dependencies, no framework.**

```
index.html          the entire app — markup, styles, and ~1,300 lines of vanilla JS
map-plain.png       hand-drawn map of Albuquerque
map-labeled.png     the same map with street names
icon-512.png        app icons
apple-touch-icon.png
```

That constraint is deliberate rather than lazy. A tool for someone learning to
drive should still work in a parking lot with no signal, so it has to be one file
you can download and open offline.

The city map has two layers: an SVG grid you can tap to name a road, drawn by
hand from the real street layout, and a raster drawing of the whole city with a
names-on/names-off toggle.

## Design decisions

- **Desert night palette**, not the usual driving-app red and yellow. The
  audience is anxious, and warning colours are the wrong register.
- **Progress is never framed as failure.** A quiz you did not pass says *review
  and try again*.
- **The scary parts are staged in order** — empty side streets first, highway
  merge last — because the sequence is the actual product.

## Running it

Open `index.html` in a browser. That's the whole procedure.

To host it, drag the folder onto [vercel.com/new](https://vercel.com/new) or
[app.netlify.com/drop](https://app.netlify.com/drop), or turn on GitHub Pages.
There is nothing to build.

## Notes

The content covers New Mexico road rules as of 2026 and is written for learning,
not as legal reference. For anything that matters, check the current
[NM MVD driver manual](https://www.mvd.newmexico.gov/).

## Licence

Code is [MIT](LICENSE). The hand-drawn maps and illustrations are ©
Elizabeth Beier — please ask before reusing those.

---

Built by [Elizabeth Beier](https://elizabethbportfolio.com) ·
[case study](https://elizabethbportfolio.com/work-drive-505.html)
